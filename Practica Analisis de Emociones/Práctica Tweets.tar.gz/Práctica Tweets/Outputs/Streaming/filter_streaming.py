
import time
def filterFile(inputName):

    inputFile = open(inputName, "r")
    outputName = "filtered_V2"+inputName

    outputFile = open(outputName, "w")

    TTs_list = []
    stateHap_list = []

    for line in inputFile:
        keyPair, value = line.split('\t')
        value = int(value[:-1])
        keyPair = keyPair[1:-1]
        keyPair = keyPair.split(',')
        keyPair[0] = keyPair[0].replace("'", "")
        keyPair[1] = keyPair[1].replace("'", "")


        if keyPair[0] == 'w':
            TTs_list.append([value, keyPair])
        elif keyPair[0] == 's':
            stateHap_list.append([value, keyPair])

        TTs_list.sort(reverse=True)
        stateHap_list.sort(reverse=True)


    for state in stateHap_list:
        # pass
        # print type(state)
        # outputFile.write(str(state[1]).replace("' ", "'"))
        outputFile.write(str(list(reversed(state))).replace("' ", "'")[1:-1])
        outputFile.write("\n")

    for word in TTs_list[:10]:
        # pass
        # print type(word)
        outputFile.write(str(list(reversed(word))).replace("' ", "'")[1:-1])
        outputFile.write("\n")

    inputFile.close()
    outputFile.close()

#filterFile("streaming60MBLocal.txt")
#filterFile("streaming600MBLocal.txt")
#filterFile("streaming2_6GBLocal.txt")
init_time = time.time()
#filterFile("streaming60MB_V2.txt")
#filterFile("streaming600MB_V2.txt")
filterFile("streaming2_6GB_V2.txt")
print "Final time for filtering: "+ str(time.time()-init_time)
