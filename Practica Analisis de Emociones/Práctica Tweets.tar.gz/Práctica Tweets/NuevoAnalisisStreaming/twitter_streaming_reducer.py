#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 20 19:26:09 2016

@author: nacho
"""

#!/usr/bin/env python
import sys
from CityToState import CityToStateDict
import time
import ast

curr_key = None
curr_count = 0


#Only for test locally
init_time = time.time()
    
rep_states = CityToStateDict.values()
list_of_states = [CityToStateDict.setdefault(x,x) for x in rep_states if x not in CityToStateDict ]

for line in sys.stdin:

    key, count = line.split('\t')
    
    
    count = int(count)
    key = ast.literal_eval(key)
    
    # If the current key is the same as the previous key, increment its
    # count, otherwise print the key count to STDOUT     

    if key == curr_key:
        curr_count += count
    else: 
        # Write key and its number of occurrences as a key-value pair to STDOUT

        if curr_key:                        
            print '{0}\t{1}'.format(curr_key, curr_count)

        curr_key = key
        curr_count = count       
        
        
# Output the count for the last key
if curr_key == key:
    print '{0}\t{1}'.format(curr_key, curr_count)


#Only for test locally
sys.stderr.write("Final reducer time: {0}\n".format(str(time.time()-init_time)))
