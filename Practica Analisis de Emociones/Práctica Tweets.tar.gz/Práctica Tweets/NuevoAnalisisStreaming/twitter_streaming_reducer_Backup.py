#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 20 19:26:09 2016

@author: nacho
"""

#!/usr/bin/env python
import sys
from CityToState import CityToStateDict
import time

curr_key = None
curr_count = 0

dicc_zone = {}
dicc_word = {}

    
def get_nTTs(dicc_TTs, most_repeated):
    '''
    This function gets the TTs into a list, sort them and gets the 
    n more repeated
    '''
    
    words = dicc_TTs.items()
    words.sort(lambda x,y:cmp(x[1], y[1]))
    print(type(words))
    words = words[len(words)-most_repeated-1:(len(words)-1)]
    return words

def getordered_TTs(list_tts):
    '''
    This function returns two different lists,
    tts and his counts in order to plot in a graphic
    '''
    tts = []
    counts = []
    for tt in list_tts:
        tts.append(tt[0])
        counts.append(tt[1])
        
    return tts, counts

#Only for test locally
init_time = time.time()
    
rep_states = CityToStateDict.values()
list_of_states = [CityToStateDict.setdefault(x,x) for x in rep_states if x not in CityToStateDict ]

for line in sys.stdin:

    key, count = line.split('\t')

    count = int(count)
    
    # If the current key is the same as the previous key, increment its
    # count, otherwise print the key count to STDOUT        
    
    if key == curr_key:
        curr_count += count
    else: 
            # Write key and its number of occurrences as a key-value pair to STDOUT
        
        if curr_key:
            if curr_key in list_of_states:
                dicc_zone[curr_key] = curr_count   
                print '{0}\t{1}'.format(["s", curr_key], curr_count)
            else:
                dicc_word[curr_key] = curr_count                   
                print '{0}\t{1}'.format(["w", curr_key], curr_count)
              

        curr_key = key
        curr_count = count       
        
        
# Output the count for the last key
if curr_key == key:
    if curr_key in CityToStateDict:
        dicc_zone[curr_key] = curr_count   
        print '{0}\t{1}'.format(["s", curr_key], curr_count)
    else:
        dicc_word[curr_key] = curr_count                   
        print '{0}\t{1}'.format(["w", curr_key], curr_count)

#Only for test locally
sys.stderr.write("Final reducer time: {0}\n".format(str(time.time()-init_time)))
