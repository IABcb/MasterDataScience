import oauth2 as oauth
import urllib2 as urllib
import csv

access_token_key = "282135577-U5Xi008zSflXafmPExzpYMiEEXtRFfWiWsdGmNS1"
access_token_secret = "YV3igfAOkIf4CC62hhH1MWUoom3sq0FLYH6slgCaGqW3F"

consumer_key = "zuAENBN5OBMhCU8Tfe6zobbgh"
consumer_secret = "mKVhWgTXYnzNLwHwprz8NMQKCG4GQDJ2XJRFbzo3QHon6G4Yyo"

_debug = 0

oauth_token    = oauth.Token(key=access_token_key, secret=access_token_secret)
oauth_consumer = oauth.Consumer(key=consumer_key, secret=consumer_secret)

signature_method_hmac_sha1 = oauth.SignatureMethod_HMAC_SHA1()

http_method = "GET"


http_handler  = urllib.HTTPHandler(debuglevel=_debug)
https_handler = urllib.HTTPSHandler(debuglevel=_debug)


fileToWrite = open("tweets.txt", "w")

'''
Construct, sign, and open a twitter request
using the hard-coded credentials above.
'''
def twitterreq(url, method, parameters):
  req = oauth.Request.from_consumer_and_token(oauth_consumer,
                                             token=oauth_token,
                                             http_method=http_method,
                                             http_url=url, 
                                             parameters=parameters)

  req.sign_request(signature_method_hmac_sha1, oauth_consumer, oauth_token)

  headers = req.to_header()

  if http_method == "POST":
    encoded_post_data = req.to_postdata()
  else:
    encoded_post_data = None
    url = req.to_url()

  opener = urllib.OpenerDirector()
  opener.add_handler(http_handler)
  opener.add_handler(https_handler)

  response = opener.open(url, encoded_post_data)

  return response

def fetchsamples():
  url = "https://stream.twitter.com/1.1/statuses/sample.json"
  parameters = []
  response = twitterreq(url, "GET", parameters)
  for line in response:
    fileToWrite.write(line)
    #print line.strip()

if __name__ == '__main__':
  fetchsamples()
