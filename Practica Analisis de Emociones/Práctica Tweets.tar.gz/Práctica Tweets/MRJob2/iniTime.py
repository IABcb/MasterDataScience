
import time

fileTime = open("calculation_time.txt", "w")
iniTime = time.time()
fileTime.write("Initial Time: " + str(iniTime))
fileTime.write("\n")
fileTime.close()
