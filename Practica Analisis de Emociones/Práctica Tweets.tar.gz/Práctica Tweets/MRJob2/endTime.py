
import time

fileTime = open("calculation_time.txt", "a")
iniTime = time.time()
fileTime.write("Final Time: " + str(iniTime))
fileTime.close()
