
import os
import time

os.system("python iniTime.py")
os.system("python TwitterMRJob.py -r emr s3://urjc.datascience.iarias/Tweets/Tweets1.txt --file AFINN-111.txt --python-archive CityToState.py --output-dir=s3://urjc.datascience.iarias/Tweets/Outputs1_1_1v2/60MB_XXXLargev3 --ec2-instance-type cc2.8xlarge --num-core-instances 1 --no-output")
os.system("python endTime.py")
