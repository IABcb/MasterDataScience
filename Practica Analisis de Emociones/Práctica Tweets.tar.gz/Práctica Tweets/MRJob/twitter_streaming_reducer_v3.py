#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 20 19:26:09 2016

@author: nacho
"""

#!/usr/bin/env python
import sys
import pandas as pd
from CityToState import CityToStateDict

curr_key = None
curr_count = 0

dicc_zone = {}
dicc_word = {}

    
def get_nTTs(dicc_TTs, most_repeated):
    '''
    This function gets the TTs into a list, sort them and gets the 
    n more repeated
    '''
    
    words = dicc_TTs.items()
    words.sort(lambda x,y:cmp(x[1], y[1]))
    print(type(words))
    words = words[len(words)-most_repeated-1:(len(words)-1)]
    return words

def getordered_TTs(list_tts):
    '''
    This function returns two different lists,
    tts and his counts in order to plot in a graphic
    '''
    tts = []
    counts = []
    for tt in list_tts:
        tts.append(tt[0])
        counts.append(tt[1])
        
    return tts, counts

rep_states = CityToStateDict.values()
list_of_states = [CityToStateDict.setdefault(x,x) for x in rep_states if x not in CityToStateDict ]

for line in sys.stdin:

    key, count = line.split('\t')

    count = int(count)
    
    # If the current key is the same as the previous key, increment its
    # count, otherwise print the key count to STDOUT        
    
    if key == curr_key:
        curr_count += count
    else: 
            # Write key and its number of occurrences as a key-value pair to STDOUT
        
        if curr_key:
            if curr_key in list_of_states:
                dicc_zone[curr_key] = curr_count   
                print '{0}\t{1}\t{2}'.format("s", curr_key, curr_count)
            else:
                dicc_word[curr_key] = curr_count                   
                print '{0}\t{1}\t{2}'.format("w", curr_key, curr_count)
              

        curr_key = key
        curr_count = count       
        
        
# Output the count for the last key
if curr_key == key:
    if curr_key in CityToStateDict:
        dicc_zone[curr_key] = curr_count   
        print '{0}\t{1}\t{2}'.format("s", curr_key, curr_count)
    else:
        dicc_word[curr_key] = curr_count                   
        print '{0}\t{1}\t{2}'.format("w", curr_key, curr_count)

# GRAPHICS
#zones = dicc_zone.keys()
#happiness = dicc_zone.values()

#zones_DF = pd.DataFrame({"Happiness": happiness}, index = zones)
#plot = zones_DF.plot(kind='bar')
#plot.set_ylabel("Happiness")
#plot.set_title("Happiness in EE.UU")

#fig = plot.get_figure()
#fig.savefig('HappinessPerZone.pdf')
#print(zones_DF)

#most_repeated = 10
#list_tts = get_nTTs(dicc_word, most_repeated) 
#ordered_tts, counts = getordered_TTs(list_tts)

#tts_EEUU = pd.DataFrame({"Count": counts}, index = ordered_tts)
#plot = tts_EEUU.plot(kind='bar')
#plot.set_ylabel("Count")
#plot.set_title("TTs in EE.UU")

#fig = plot.get_figure()
#fig.savefig('TTsinEEUU.pdf')
#print(tts_EEUU)

