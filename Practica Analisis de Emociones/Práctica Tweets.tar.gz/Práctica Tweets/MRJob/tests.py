# -*- coding: utf-8 -*-


def WordSplitter(text):
    '''
    This function splits the text into space separated words in order
    to calculate trending topics in the reducer process.
    '''
    splitted_text = text.split(" ")
    words_dicc = {}
    for word in splitted_text:
        if word in words_dicc:
            words_dicc[word] += 1
        else:
            words_dicc[word] = 1
    return words_dicc
    
textToCheck = "Hello Hello"
print WordSplitter(textToCheck)