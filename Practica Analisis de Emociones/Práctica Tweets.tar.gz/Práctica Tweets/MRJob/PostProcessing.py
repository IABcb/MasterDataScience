# -*- coding: utf-8 -*-
"""
Created on Sun Dec  4 12:40:13 2016

@author: raul
"""

import ast
import pandas as pd
import seaborn as sns
from StatesDic import statesDic

dataFileName = "raulResults3.txt"

def getRawData(dataFileName):
    dataFile = open(dataFileName, "r")
    statesNameList = []
    statesScoreList = []
    wordsNameList = []
    wordsScoreList = []
    for line in dataFile:
        line = line.split("\t")
        keyWordState = ast.literal_eval(line[0])
        key , wordState = keyWordState[0], keyWordState[1]
        value = line[1][:-1]
        if key == "s":
            statesNameList.append(wordState)
            statesScoreList.append(int(value))
        elif key == "w":
            wordsNameList.append(wordState)
            wordsScoreList.append(int(value))
    statesDic2 = {y:x for x,y in statesDic.iteritems()}
    statesNameList2 = [statesDic2[n] if n in statesDic2.keys() else n for n in statesNameList]
#    dfStates = pd.DataFrame({"Felicidad":statesScoreList}, index = statesNameList)
#    dfWords = pd.DataFrame({"Repeticiones":wordsScoreList}, index = wordsNameList)
    
    dfStates = pd.DataFrame({"Estado":statesNameList, "Felicidad":statesScoreList})
    dfStates2 = pd.DataFrame({"Estado":statesNameList2, "Felicidad":statesScoreList})
    dfWords = pd.DataFrame({"Palabra":wordsNameList, "Repeticiones":wordsScoreList})
    
    dfStates.to_csv("dfStates.csv")
    dfStates2.to_csv("dfStates2.csv")
    dfWords.to_csv("dfWords.csv")
#    return dfStates, dfWords

def plotTT(dfWords):
    plot = dfWords.plot(kind="bar", rot = 0, legend = False)
    plot.set_ylabel("Repeticiones")
    plot.set_title("Trending Topics")
    plot.set_xlabel("Palabra")
    fig = plot.get_figure()
    fig.savefig('TrendingTopic.pdf')
    
def plotStates(dfStates):
    plot = dfStates.plot(kind="bar", rot = 90, legend = False)
    plot.set_ylabel("Felicidad")
    plot.set_title("Felicidad por estado")
    plot.set_xlabel("Estado")
    fig = plot.get_figure()
    fig.savefig('StatesHapinnes.pdf')

if __name__ == "__main__":
    getRawData(dataFileName)
#    dfStates, dfWords = getRawData(dataFileName)
#    plotTT(dfWords)
#    plotStates(dfStates)
