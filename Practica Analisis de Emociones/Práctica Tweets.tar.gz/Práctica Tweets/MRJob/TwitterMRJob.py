# -*- coding: utf-8 -*-

from mrjob.job import MRJob
from mrjob.step import MRStep
import json
from CityToState import CityToStateDict
import re
import sys
import time

 
class TwitterMRJob(MRJob):
        
    def GetScoresDic(self, fileName):
        '''
        Function that returns a dictionary where each key is a word
        and the value of that key is its score.
        The function has one input, the file name of the .txt file
        where the score of each word is specified
        '''

        wordScore = {}
        fileScoresDic = open(fileName)
        for line in fileScoresDic:
            word, score = line.split("\t")
            if score[-1] == "\n":
                score = score[:-1]
            wordScore[word] = int(score)
        return wordScore
        
    def GetStateFromCity(self, city, CityToStateDic):
        '''
        Function that returns the State of a city from the US giving
        two arguments: the name of the city ("city"); and a dictionary
        where each key-value pair is defined as the name of a city of the US 
        and the corresponding State. This dictionary has to be obtained 
        beforehand
        '''

        state = None
        if city in CityToStateDic:
            state = CityToStateDic[city]
        return state
        
    def FilterTweets(self, jsonLine, CityToStateDic):
        '''
        This function takes as an argument a Tweet in JSON format ("jsonLine"). 
        In addition, a dicctionary ("CityToStateDic"), where each key-value pair is 
        defined as the name of a city of the US and its corresponding State, has to
        be included as an input. This dictionary has to be obtained beforehand.
        This function returns the text and the state of each Tweet (as a dictionary) 
        only if the following conditions are met:
            * The country is US
            * The specified type of place from where the Tweet was made is "city"
            * The language is English
        If that conditions are not met, a "None" value is returned
        '''

        place = None
        countryCode = None
        text = None
        state = None
        try:
            place = jsonLine["place"]
            text = jsonLine["text"]
            language = jsonLine["lang"]
        except KeyError:
            pass
        if place:
            countryCode = place["country_code"]
            if countryCode == "US" and place["place_type"] == "city":
                city = place["name"]
                state = self.GetStateFromCity(city, CityToStateDic)                  
        
        if text and state and language == "en":
            dic = {"state":state, "text": text}
            return dic
        else:
            return None
               
    def ApplyScoresWords(self, text, scoresDic):
        '''
        This function calculates the score of a given text ("text") as a function
        of predefined word-score relation, which has to be provided as a dictionary
        ("scoresDic")
        '''
        totalScore = 0
        for word in text.split():
            scoreWord = 0
            try:
                scoreWord = scoresDic[word]
            except KeyError:
                pass
            totalScore += scoreWord
        return totalScore        
    
    def WordSplitter(self, text):
        '''
        This function splits the text into space separated words in order
        to calculate trending topics in the reducer process.
        '''
        splitted_text = text.split(" ")
        words_dicc = {}
        for word in splitted_text:
            if word in words_dicc:
                words_dicc[word] += 1
            else:
                words_dicc[word] = 1
        return words_dicc
    
    def is_word(self, word):
        '''
        This function analizes the word in order to delete every no-word
        '''
        patron = re.compile("^[a-z,A-Z]+$")
        return patron.match(word) != None         

    def mapper_get_words_and_states(self,_,line):
        '''
        This function create an interator with the following items:
            - key = letter, word
            - value = value
        Each key can be:
            - letter: 
                * w, if the word is a word from the tweet
                * s, if the word is the state of EEU where the tweet has been written
            - word:
                * word, if it is a word from the tweet
                * state, if it is the state where the tweet has been written
        Each value can be:
            - 1, if key is a word
            - happiness value, if the word is a state
        '''               
        keyword = 'w'        
        keystate = 's'
        scoresDic = self.GetScoresDic("/home/raul/Dropbox/Master-DS/Práctica Tweets/MRJob/AFINN-111.txt")
        jsonLine = json.loads(line, encoding='utf-8')
        
        # Then we filter the Tweets and we only keep that ones that are or our 
        # interest
        filteredLine = self.FilterTweets(jsonLine, CityToStateDict)
        
        
        if filteredLine:
            #We get the text from the tweet
            text = filteredLine["text"]
            
            # For each Tweet of interest, we get the score
            score = self.ApplyScoresWords(text, scoresDic)
        
            # We split the text in order to calculate TT's        
            tweet_words_dicc = self.WordSplitter(text)
                
            # We produce a pair of key - value for the trending topic calculator 
            #and the happiness process                    	
            tweet_word_keys = tweet_words_dicc.keys()
            for tweet_word in tweet_word_keys:                 
                if self.is_word(tweet_word):                
                    yield (keyword, tweet_word) , tweet_words_dicc[tweet_word]
            yield (keystate, filteredLine["state"]), score

            
    def combiner_sum_values(self, word_or_state, value):
        '''
        This functions sets an iterator with:
            key = word or state plus w or s
            value = sum of the values for the same word or state
        '''

        yield word_or_state, sum(value)


    def reducer_prepare_for_TTs(self, word_or_state, counts):  
        '''
        This function sets an iterator with the key None. This key will send 
        all the words and state to the same reducer in order to calculate the 10 TTs
        '''

        yield None, (sum(counts), word_or_state)
        

    def reducer_get_TTs_states(self, _, word_or_state_count_pairs):
        '''
        This functions sets two iterators. 
        The first one extracts the words into a list
        in order to sort the values and get the 10 TTs.
        The second one contains the states and the happiness
        '''
        TTs_list = []
        stateHap_list = []
        for word_or_state in word_or_state_count_pairs:
            if word_or_state[1][0] == 'w':
                TTs_list.append(word_or_state)
            else:
                stateHap_list.append(word_or_state) 
        TTs_list.sort(reverse=True)
        stateHap_list.sort(reverse=True)
        for state in stateHap_list:
            yield list(reversed(state))
        for word in TTs_list[:10]:
            yield list(reversed(word))
                    
        
    def steps(self):
        '''
        This function sets an order in the map-reduce process
        '''
        return [MRStep(mapper=self.mapper_get_words_and_states,                   
                combiner=self.combiner_sum_values,
                reducer=self.reducer_prepare_for_TTs),
                MRStep(reducer=self.reducer_get_TTs_states)
                   ]      	
        
if __name__=='__main__':    
    fileTime = open("calculation_time.txt", "w")
    init_time = time.time()
    TwitterMRJob.run() 
    calculationTime = time.time()-init_time
    fileTime.write("Final time: " + str(calculationTime))
#    fileTime.write("\n")
#    fileTime.write("Final time: {0}\n".format(str(calculationTime)))
    #sys.stderr.write("Final time: {0}\n".format(str(time.time()-init_time)))

    
    
    
