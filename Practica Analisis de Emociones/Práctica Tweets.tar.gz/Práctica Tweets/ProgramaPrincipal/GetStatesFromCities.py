


# Code from: https://galeascience.wordpress.com/2016/03/23/us-city-to-state-python-dictionary/


# the Geonamescache library contains information
# about continents, cities and US states
import geonamescache
 
# finding the state based on geotags
# (i.e. longitude and latitude)
from geopy.geocoders import Nominatim


gc = geonamescache.GeonamesCache()
c = gc.get_cities()
 
# extract the US city names and coordinates
US_cities = [c[key]['name'] for key in list(c.keys())
             if c[key]['countrycode'] == 'US']
US_longs = [c[key]['longitude'] for key in list(c.keys())
            if c[key]['countrycode'] == 'US']
US_latts = [c[key]['latitude'] for key in list(c.keys())
            if c[key]['countrycode'] == 'US']


for city in US_cities:
	print city



def get_states(longs, latts):
    ''' Input two 1D lists of floats/ints '''
# a list of states
    states = []
 
    # use a coordinate tool from the geopy library
    geolocator = Nominatim()
    for lon, lat in zip(longs, latts):
	print lon, lat
        try:
            # get the state name
            location = geolocator.reverse(str(lat)+', '+str(lon))
            state = location.raw['address']['state']
        except:
            # return empty string
            state = ''
        states.append(state)
    return states



#US_states = get_states(US_longs, US_latts)


#for key in US_states:
#	print key, US_states[key]
