#!/usr/bin/env python
import sys
import pandas as pd


curr_zone = None
curr_count = 0
dicc_zone = {}

def save_count_zone(dicc, zone, count):
	if zone in dicc:
		dicc[zone] = dicc[zone] + count
	else:
		dicc[zone] = count		
	return dicc

for line in sys.stdin:

	zone, count = line.split('\t')
	count = int(count)

	# If the current zone is the same as the previous zone, increment its
	# count, otherwise print the zones count to STDOUT
	if zone == curr_zone:
		curr_count += count
	else: 
		# Write zone and its number of occurrences as a key-value pair to STDOUT
		if curr_zone:
			print '{0}\t{1}'.format(curr_zone, curr_count)
			save_count_zone(dicc_zone, curr_zone, curr_count)

		curr_zone = zone
		curr_count = count

# Output the count for the last zone
if curr_zone == zone:
	print '{0}\t{1}'.format(curr_zone, curr_count)
	save_count_zone(dicc_zone, curr_zone, curr_count)


zones = dicc_zone.keys()
happiness = dicc_zone.values()

zones_DF = pd.DataFrame({"Happiness": happiness}, index = zones)
plot = zones_DF.plot(kind='bar')
plot.set_ylabel("Happiness")
plot.set_title("Happiness in EE.UU")

fig = plot.get_figure()
fig.savefig('HappinessPerZone.pdf')
print(zones_DF)


