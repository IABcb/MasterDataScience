#!/usr/bin/env python
import sys
import json

#sys.path.append('.')

fileWords = open("AFINN-111.txt")

place_key = "place"
country_key = "country"
language_key = "lang"
text_key = "text"
city_key = "name"

def GetScoresDic(fileName):
	'''
	Function that returns a dictionary where each key is a word
	and the value of that key is its score.
	The function has one input, the file name of the .txt file
	where the score of each word is specified
	'''
	wordScore = {}
	fileScoresDic = open(fileName)
	for line in fileScoresDic:
		word, score = line.split("\t")
		if score[-1] == "\n":
			score = score[:-1]
		wordScore[word] = int(score)
	return wordScore


wordScore = GetScoresDic("AFINN-111.txt")

for line in sys.stdin:
	record = json.loads(line, encoding='latin-1')

	try:
		place = record[place_key]
		language = record[language_key]
		text = record[text_key]
		if place:
			if place[country_key]:
				print("Pais: " + str(place[country_key]))
			if place[city_key]:
				print("Ciudad: " + str(place[city_key]))
		if language:
			print("Language: " + str(language))
		if text:
			print("Texto: " +str(text))
			text = text.strip()
			words = text.split()

			#La lista words hay que compararla con las palabras de AFINN-111.txt
	except:
		pass

#file = open("file.txt")
#scores = {} # initialize an empty dictionary
#for line in file:
#	term, score = line.split("\t") # The file is tab-delimited.
#	scores[term] = int(score) # Convert the score to an integer
#				# In case of Redondo_words.txt,
#				#a float should be used
#
#	print scores.items()	# Print every (term, score) pair in
#				# the dictionary
#
#
#		print '{0}\t{1}'.format(key,value)

