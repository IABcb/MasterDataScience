#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 21:25:00 2016

@author: Raul Sanchez Martin
"""

import sys
import json
from CityToState import CityToStateDict


def GetScoresDic(fileName):
    '''
    Function that returns a dictionary where each key is a word
    and the value of that key is its score.
    The function has one input, the file name of the .txt file
    where the score of each word is specified
    '''
    wordScore = {}
    fileScoresDic = open(fileName)
    for line in fileScoresDic:
        word, score = line.split("\t")
        if score[-1] == "\n":
            score = score[:-1]
        wordScore[word] = int(score)
    return wordScore
    
def GetStateFromCity(city, CityToStateDic):
    '''
    Function that returns the State of a city from the US giving
    two arguments: the name of the city ("city"); and a dictionary
    where each key-value pair is defined as the name of a city of the US 
    and the corresponding State. This dictionary has to be obtained 
    beforehand
    '''
    state = None
    if city in CityToStateDic:
        state = CityToStateDic[city]
    return state
    
def FilterTweets(jsonLine, CityToStateDic):
    '''
    This function takes as an argument a Tweet in JSON format ("jsonLine"). 
    In addition, a dicctionary ("CityToStateDic"), where each key-value pair is 
    defined as the name of a city of the US and its corresponding State, has to
    be included as an input. This dictionary has to be obtained beforehand.
    This function returns the text and the state of each Tweet (as a dictionary) 
    only if the following conditions are met:
        * The country is US
        * The specified type of place from where the Tweet was made is "city"
        * The language is English
    If that conditions are not met, a "None" value is returned
    '''
    place = None
    countryCode = None
    text = None
    state = None
    try:
        place = jsonLine["place"]
        text = jsonLine["text"]
        language = jsonLine["lang"]

    except KeyError:
        pass
    if place:
        countryCode = place["country_code"]
        if countryCode == "US" and place["place_type"] == "city":
            city = place["name"]
            state = GetStateFromCity(city, CityToStateDic)                  
    
    if text and state and language == "en":
        dic = {"state":state, "text": text}
        return dic
    else:
        return None
        


def ApplyScoresWords(text, scoresDic):
    '''
    This function calculates the score of a given text ("text") as a function
    of predefined word-score relation, which has to be provided as a dictionary
    ("scoresDic")
    '''
    totalScore = 0
    for word in text.split():
        scoreWord = 0
        try:
            scoreWord = scoresDic[word]
        except KeyError:
            pass
        totalScore += scoreWord
    return totalScore

#First we obtain a dictionary where the score of each word is included    
scoresDic = GetScoresDic("AFINN-111.txt")
        
for line in sys.stdin:
    # Get an JSON object from each line
    jsonLine = json.loads(line, encoding='utf-8')
    
    # Then we filter the Tweets and we only keep that ones that are or our 
    # interest
    filteredLine = FilterTweets(jsonLine, CityToStateDict)
    
    
    if filteredLine:
        text = filteredLine["text"]

        # For each Tweet of interest, we get the score
        score = ApplyScoresWords(text, scoresDic)
        
        # Finally, we print the state and score
        print '{0}\t{1}'.format(filteredLine["state"], score)
            
