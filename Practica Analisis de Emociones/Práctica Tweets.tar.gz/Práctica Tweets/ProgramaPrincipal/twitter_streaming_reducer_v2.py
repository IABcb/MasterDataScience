#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 20 19:26:09 2016

@author: nacho
"""

#!/usr/bin/env python
import sys
import pandas as pd
import re

curr_zone = None
curr_word = None
curr_count = 0
dicc_zone = {}
dicc_word = {}

def save_count_zone(dicc, zone, count):
    ''''
    This function save the state and the happiness score in order to
    plot the data into a graphic
    '''
    if zone in dicc:
        dicc[zone] = dicc[zone] + count
    else:
        dicc[zone] = count		
    return dicc


def key_splitter(key):
    '''
    This function splits the received pair of keys
    '''
    key = key.strip()
    key1 = key.split(",")[0]
    key1 = key1.split("'")[1]
    key2 = key.split(",")[1]
    key2 = key2.split("'")[1]
    return [key1, key2]

def is_word(word):
    '''
    This function analize the word in order to delete every no-word
    '''
    patron = re.compile("^[a-z,A-Z]+$")
    return patron.match(word) != None
    
def get_nTTs(dicc_TTs, most_repeated):
    '''
    This function gets the TTs into a list, sort them and gets the 
    n more repeated
    '''
    
    words = dicc_TTs.items()
    words.sort(lambda x,y:cmp(x[1], y[1]))
    print(type(words))
    words = words[len(words)-most_repeated-1:(len(words)-1)]
    return words

def getordered_TTs(list_tts):
    '''
    This function returns two different lists,
    tts and his counts in order to plot in a graphic
    '''
    tts = []
    counts = []
    for tt in list_tts:
        tts.append(tt[0])
        counts.append(tt[1])
        
    return tts, counts
for line in sys.stdin:

    key, count = line.split('\t')
    key = key_splitter(key)
    count = int(count)
    
    if key[0] == "state":
        # If the current zone is the same as the previous zone, increment its
        # count, otherwise print the zones count to STDOUT
        zone = key[1]
        
        if zone == curr_zone:
            curr_count += count
        else: 
            # Write zone and its number of occurrences as a key-value pair to STDOUT
            if curr_zone:
                print '{0}\t{1}'.format(curr_zone, curr_count)
                dicc_zone[curr_zone] = curr_count            

            curr_zone = zone
            curr_count = count       
        
        
       
    elif key[0] == "word":
        
        word = key[1]
        
        # Output the count for the last zone
        if curr_zone == zone:
            print '{0}\t{1}'.format(curr_zone, curr_count)
            dicc_zone[curr_zone] = curr_count
            
            # We change the value of curr_zone in order to not evaluate this sentence again
            curr_zone = None
            
            # We initialize the word and curr_count for the trending topics
            curr_count = count            
            curr_word = word
            
            
        else:
            # If the current word is the same as the previous word, increment its
            # count, otherwise print the words count to STDOUT
            if is_word(word):
                if word == curr_word:
                    curr_count += count
                    
                else: 
                    # Write word and its number of occurrences as a key-value pair to STDOUT
                    print '{0}\t{1}'.format(curr_word, curr_count)                   
                    dicc_word[curr_word] = curr_count
                    
                    curr_word = word
                    curr_count = count    
                    
# Output the count for the last zone
if curr_word == word:
    print '{0}\t{1}'.format(curr_word, curr_count)
    dicc_word[curr_word] = curr_count
    


# GRAPHICS
    
zones = dicc_zone.keys()
happiness = dicc_zone.values()

zones_DF = pd.DataFrame({"Happiness": happiness}, index = zones)
plot = zones_DF.plot(kind='bar')
plot.set_ylabel("Happiness")
plot.set_title("Happiness in EE.UU")

fig = plot.get_figure()
fig.savefig('HappinessPerZone.pdf')
print(zones_DF)

most_repeated = 10
list_tts = get_nTTs(dicc_word, most_repeated) 
ordered_tts, counts = getordered_TTs(list_tts)

tts_EEUU = pd.DataFrame({"Count": counts}, index = ordered_tts)
plot = tts_EEUU.plot(kind='bar')
plot.set_ylabel("Count")
plot.set_title("TTs in EE.UU")

fig = plot.get_figure()
fig.savefig('TTsinEEUU.pdf')
print(tts_EEUU)

