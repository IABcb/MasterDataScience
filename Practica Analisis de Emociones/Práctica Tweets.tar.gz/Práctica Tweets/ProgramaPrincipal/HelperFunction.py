#!/usr/bin/env python2


import json
import geonamescache
from geopy.geocoders import Nominatim
from CityToState import CityToStateDict

def GetScoresDic(fileName):
    '''
    Function that returns a dictionary where each key is a word
    and the value of that key is its score.
    The function has one input, the file name of the .txt file
    where the score of each word is specified
    '''
    wordScore = {}
    fileScoresDic = open(fileName)
    for line in fileScoresDic:
        word, score = line.split("\t")
        if score[-1] == "\n":
            score = score[:-1]
        wordScore[word] = int(score)
    return wordScore
 

def FilterTweets(fileNameInput, fileNameOutput, CityToStateDict):
    '''
    Function that reads line by line a file in JSON format
    and returns another file in the same format including only
    that lines which meet some conditions.
    '''
    iniTweetsFile = open(fileNameInput, "r")
    outputTweetsFile = open(fileNameOutput, "w")
    
    
    for iniLine in iniTweetsFile:
        jsonLine = json.loads(iniLine, encoding='utf8')
        place = None
        countryCode = None
        text = None
        state = None
        try:
            place = jsonLine["place"]
            text = jsonLine["text"]
        except KeyError:
            pass
        if place:
            countryCode = place["country_code"]
            if countryCode == "US" and place["place_type"] == "city":
                city = place["name"]
                state = GetStateFromCity(city, CityToStateDict)                  
        
        if text and state:
#            dic = {"Country Code":place}
            dic = {"State":state, "Text": text}
            outputTweetsFile.write(str(dic)+"\n")
            
    iniTweetsFile.close()
    outputTweetsFile.close()
    
    
    
    
    
def GetAllUSCities():
    gc = geonamescache.GeonamesCache()
    cities = gc.get_cities()
    US_cities = {}
    for key in cities:
        if cities[key]['countrycode'] == 'US':
            cityName = cities[key]['name']
            longitude = cities[key]['longitude']
            latitutde = cities[key]['latitude']
            US_cities[cityName] = [longitude, latitutde]
    return US_cities
    

def GetStateFromCity(city, CityToStateDict):
    state = None
    if city in CityToStateDict:
        state = CityToStateDict[city]
    return state
        

#def GetState(longitude, latitude):
#    ''' 
#    Input two 1D lists of floats/ints 
#    '''
#    geolocator = Nominatim()
#    try:
#        print longitude, latitude
#        location = geolocator.reverse(str(longitude)+', '+str(latitude))
#        state = location.raw['address']['state']
#    except:
#        # return empty string
#        state = None
#    return state
    
    


def GetState(longs, latts):
    ''' Input two 1D lists of floats/ints '''
    # a list of states
    states = []
    # use a coordinate tool from the geopy library
    geolocator = Nominatim()
    for lon, lat in zip(longs, latts):
        try:
            # get the state name
            location = geolocator.reverse(str(lat)+', '+str(lon))
            state = location.raw['address']['state']
        except:
            # return empty string
            state = ''
        states.append(state)
    return states[0]

    

if __name__ == "__main__":
#    FilterTweets("Tweets1.txt", "FilteredTweetsRaul.txt", CityToStateDict)
#    allUSCities = GetAllUSCities()
#    for city in allUSCities:
#        if city == "Manhattan":
#            print city, allUSCities[city][0], allUSCities[city][1]
#            print GetState([allUSCities[city][0]], [allUSCities[city][1]])

