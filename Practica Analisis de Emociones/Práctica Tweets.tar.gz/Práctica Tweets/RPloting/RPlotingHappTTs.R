
library(ggplot2)
library(extrafont)

#font_import()
loadfonts()

calculateHappiness <- function(state){
    myStateData = read.csv("dfStates.csv")
    myStateData$Estado = tolower(myStateData$Estado)
    if(state %in% myStateData$Estado){
        myStateData[myStateData$Estado == state, "Felicidad"]}
    else {
        NaN}
}

plotMapHappiness <- function(){
    states <- map_data("state")
    nameStates <- unique(states$region)
    myStateData = read.csv("dfStates.csv")
    myStateData$Estado = tolower(myStateData$Estado)
    states$Felicidad <- sapply(states$region, function(x) calculateHappiness(x))
    plot <- ggplot(data = states)  
    plot <- plot + geom_polygon(aes(x = long, y = lat, fill = Felicidad, group = group), color = "black", size = 0.25)
    plot <- plot + coord_fixed(1.3) + scale_fill_gradientn(colours = rev(rainbow(7)))
    plot <- plot + xlab("Longitud") + ylab("Latitud")
    #plot <- plot + ggtitle("              Distribución de la felicidad por estados")
    plot <- plot + theme(text=element_text(family="Times New Roman", size = 10))
    plot <- plot + theme(axis.text=element_text(size=8))
    plot <- plot + theme(axis.title=element_text(size=10))
    ggsave("MapHappiness.pdf", width=15, height=8, units = "cm")
}

plotBarHappiness <- function(){
    myStateData <- read.csv("dfStates2.csv")
    myStateData$Estado <- as.character(myStateData$Estado)
    myStateData$Estado <- factor(myStateData$Estado, levels=unique(myStateData$Estado))
    #print(myStateData)
    plot <- ggplot(data = myStateData, aes(x = Estado, y = Felicidad)) + geom_bar(stat="identity", width=0.75)
    plot <- plot + theme(axis.text=element_text(size=6))
    plot <- plot + theme(axis.title=element_text(size=10))
    plot <- plot + theme(text=element_text(family="Times New Roman"))
    ggsave("BarHappiness.pdf", width=17, height=7.5, units = "cm")
}

plotBarTTs <- function(){
    myTweets <- read.csv("dfWords.csv")
    myTweets$Palabra <- as.character(myTweets$Palabra)
    myTweets$Palabra <- factor(myTweets$Palabra, levels=unique(myTweets$Palabra))
    plot <- ggplot(data = myTweets, aes(x = Palabra, y = Repeticiones)) + geom_bar(stat = "identity")
    plot <- plot + theme(axis.text.x = element_text(angle = 90, hjust = 1))
    plot <- plot + theme(axis.text=element_text(size=8))
    plot <- plot + theme(axis.title=element_text(size=10))
    plot <- plot + theme(text=element_text(family="Times New Roman"))
    ggsave("BarTweets.pdf", width=9, height=7.5, units = "cm")
}

plotMapHappiness()
plotBarHappiness()
plotBarTTs()