
library(ggplot2)
library(extrafont)
loadfonts()


PlotTotalLocal <- function(){
    localExecution = data.frame(Modo.Ejecución = factor(c(rep("streaming", 3), rep("mrjob", 3)), levels = c("streaming", "mrjob")), 
                                Tamaño.Archivo.MBs = factor(rep(c(60, 600, 2600), 2)),
                                Tiempo.Cálculo.s = c(3.741627, 37.95975, 167.6237, 30.6180, 311.148, 1168.034))
    
    plot <- ggplot(data = localExecution, aes(x = Modo.Ejecución, y = Tiempo.Cálculo.s, fill = Tamaño.Archivo.MBs)) + geom_bar(stat="identity", position=position_dodge())
    plot <- plot + theme(text=element_text(family="Times New Roman", size = 10))
    plot <- plot + theme(axis.text=element_text(size=8))
    plot <- plot + theme(axis.title=element_text(size=10))
    #plot <- plot + scale_y_log10()
    plot <- plot + xlab("Módo de ejecución") + ylab("Tiempo de cálculo (s)")
    plot <- plot + scale_fill_discrete(name="Tamaño de \n archivo (MBs)")
    ggsave("ExecutionLocal.pdf", width=13, height=7.5, units = "cm")
}


PlotTotalMrjob <- function(){
    totalMrjob = data.frame(Máquina.Ejecución = factor(c(rep("local", 3), rep("c1.medium", 3), rep("c1.xlarge", 3), rep("cc2.8xlarge", 3)), levels = c("local", "c1.medium", "c1.xlarge", "cc2.8xlarge")), 
                                Tamaño.Archivo.MBs = factor(rep(c(60, 600, 2600), 4)),
                                Tiempo.Cálculo.s = c(30.6180, 311.148, 1168.034,
                                                     1678.09, 2848.97, NaN,
                                                     1665.66, 1983.76, 3531.32,
                                                     2477.08, 2180.96, 2435.60))
    
    plot <- ggplot(data = totalMrjob, aes(x = Máquina.Ejecución, y = Tiempo.Cálculo.s, fill = Tamaño.Archivo.MBs)) + geom_bar(stat="identity", position=position_dodge())
    plot <- plot + theme(text=element_text(family="Times New Roman", size = 10))
    plot <- plot + theme(axis.text=element_text(size=8))
    plot <- plot + theme(axis.title=element_text(size=10))
    #plot <- plot + scale_y_log10()
    plot <- plot + xlab("Máquina de ejecución") + ylab("Tiempo de cálculo (s)")
    plot <- plot + scale_fill_discrete(name="Tamaño de \n archivo (MBs)")
    ggsave("ExecutionTotalMrjob.pdf", width=13, height=7.5, units = "cm")
}

PlotStep1Mrjob <- function(){
    totalMrjob = data.frame(Máquina.Ejecución = factor(c(rep("c1.medium", 3), rep("c1.xlarge", 3), rep("cc2.8xlarge", 3)), levels = c("local", "c1.medium", "c1.xlarge", "cc2.8xlarge")), 
                            Tamaño.Archivo.MBs = factor(rep(c(60, 600, 2600), 3)),
                            Tiempo.Cálculo.s = c(228.9, 1404.8, NaN,
                                                 142.8, 519.6, 1784.2,
                                                 125.1, 109.6, 294.3))
    
    plot <- ggplot(data = totalMrjob, aes(x = Máquina.Ejecución, y = Tiempo.Cálculo.s, fill = Tamaño.Archivo.MBs)) + geom_bar(stat="identity", position=position_dodge())
    plot <- plot + theme(text=element_text(family="Times New Roman", size = 10))
    plot <- plot + theme(axis.text=element_text(size=8))
    plot <- plot + theme(axis.title=element_text(size=10))
    #plot <- plot + scale_y_log10()
    plot <- plot + xlab("Máquina de ejecución") + ylab("Tiempo de cálculo (s)")
    plot <- plot + scale_fill_discrete(name="Tamaño de \n archivo (MBs)")
    ggsave("ExecutionStep1Mrjob.pdf", width=13, height=7.5, units = "cm")
}

PlotTotalLocal()
PlotTotalMrjob()
PlotStep1Mrjob()