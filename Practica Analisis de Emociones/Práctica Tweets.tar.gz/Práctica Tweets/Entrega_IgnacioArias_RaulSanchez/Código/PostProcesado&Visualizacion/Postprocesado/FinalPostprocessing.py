# -*- coding: utf-8 -*-

import ast
import pandas as pd
from StatesDic import statesDic

dataFileName = "raulResultasMRjob60Mbs.txt"

def getRawData(dataFileName):
    dataFile = open(dataFileName, "r")
    statesNameList = []
    statesScoreList = []
    wordsNameList = []
    wordsScoreList = []
    for line in dataFile:
        line = line.split("\t")
        keyWordState = ast.literal_eval(line[0])
        key , wordState = keyWordState[0], keyWordState[1]
        value = line[1][:-1]
        if key == "s":
            statesNameList.append(wordState)
            statesScoreList.append(int(value))
        elif key == "w":
            wordsNameList.append(wordState)
            wordsScoreList.append(int(value))
    statesDic2 = {y:x for x,y in statesDic.iteritems()}
    statesNameList2 = [statesDic2[n] if n in statesDic2.keys() else n for n in statesNameList]
    
    dfStates = pd.DataFrame({"Estado":statesNameList, "Felicidad":statesScoreList})
    dfStates2 = pd.DataFrame({"Estado":statesNameList2, "Felicidad":statesScoreList})
    dfWords = pd.DataFrame({"Palabra":wordsNameList, "Repeticiones":wordsScoreList})
    
    dfStates.to_csv("dfStates.csv")
    dfStates2.to_csv("dfStates2.csv")
    dfWords.to_csv("dfWords.csv")

if __name__ == "__main__":
    getRawData(dataFileName)