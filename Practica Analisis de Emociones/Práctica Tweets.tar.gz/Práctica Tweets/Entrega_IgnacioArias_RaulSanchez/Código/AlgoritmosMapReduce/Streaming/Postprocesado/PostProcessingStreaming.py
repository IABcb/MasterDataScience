
dataFileName = "raulStreaming60MBs.txt"

def filterFile(inputName):

    inputFile = open(inputName, "r")
    outputName = "filtered_"+inputName

    outputFile = open(outputName, "w")

    TTs_list = []
    stateHap_list = []

    for line in inputFile:
        keyPair, value = line.split('\t')
        value = int(value[:-1])
        keyPair = keyPair[1:-1]
        keyPair = keyPair.split(',')
        keyPair[0] = keyPair[0].replace("'", "")
        keyPair[1] = keyPair[1].replace("'", "")


        if keyPair[0] == 'w':
            TTs_list.append([value, keyPair])
        elif keyPair[0] == 's':
            stateHap_list.append([value, keyPair])

        TTs_list.sort(reverse=True)
        stateHap_list.sort(reverse=True)


    for state in stateHap_list:
        outputFile.write(str(list(reversed(state))).replace("' ", "'")[1:-1])
        outputFile.write("\n")

    for word in TTs_list[:10]:
        outputFile.write(str(list(reversed(word))).replace("' ", "'")[1:-1])
        outputFile.write("\n")

    inputFile.close()
    outputFile.close()

if __name__=='__main__':
	filterFile(dataFileName)
